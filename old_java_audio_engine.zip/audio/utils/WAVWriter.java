package nl.igorski.lib.audio.utils;

import nl.igorski.kosm.util.CacheReader;
import nl.igorski.lib.audio.renderer.AudioRenderer;
import nl.igorski.lib.utils.storage.FileSystem;
import uk.labbookpages.wave.WavFile;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 27-06-12
 * Time: 21:20
 * To change this template use File | Settings | File Templates.
 */
public final class WAVWriter
{
    /**
     * writes a mono audio buffer into a stereo WAVE file
     *
     * @param aBuffer   {double[]}
     * @param aFileName {String}
     *
     * @return {WavFile}
     */
    public static WavFile writeBufferToFile( double[] aBuffer, String aFileName )
    {
        WavFile output = null;

        try
        {
            final int sampleRate  = AudioRenderer.SAMPLE_RATE;
            final long numSamples = aBuffer.length;

            // create a stereo WAV file w/ the specified properties
            if ( !aFileName.contains( ".wav" ) && !aFileName.contains( "." ))
                aFileName = aFileName + ".wav";

            output = WavFile.newWavFile( FileSystem.open( aFileName ), 2, numSamples, 16, sampleRate );

            // create a local buffer
            final int bufferLength = 1024;
            double[][] localBuffer = new double[ 2 ][ bufferLength ];

            int frameCounter = 0;

            /* input buffer is (currently) a mono signal, we
               use the temporary local buffer to write the signal to
               two sides of the stereo field for stereo output */

            while ( frameCounter < numSamples )
            {
                final long remaining  = output.getFramesRemaining();
                final int writeAmount = ( remaining > bufferLength ) ? bufferLength : ( int ) remaining;

                // fill the stereo buffer
                for ( int s = 0; s < writeAmount; s++, frameCounter++ )
                {
                    final double theSample = aBuffer[ frameCounter ];

                    localBuffer[ 0 ][ s ] = theSample;
                    localBuffer[ 1 ][ s ] = theSample;
                }
                // write into file
                output.writeFrames( localBuffer, writeAmount );
            }
            // close the file
            output.close();
        }
        catch ( Exception e ) {}

        return output;
    }

    /**
     * to prevent excessive memory usage when writing a large recording (containing buffer-sized fragments)
     * this method writes straight from the buffer Vector to prevent the need for a temporary (large) buffer
     * for use with the method above
     *
     * @param aCachedFiles {String[]} all files containing the output cache
     * @param aFileName    {String}   output name of WAVE file
     *
     * @return {WavFile}
     */
    public static WavFile writeRecordingToFile( String[] aCachedFiles, String aFileName )
    {
        WavFile output = null;

        try
        {
            final int sampleRate  = AudioRenderer.SAMPLE_RATE;
            long numSamples       = 0;

            // calculate the amount of samples to write
            for ( final String cachedFile : aCachedFiles )
            {
                numSamples += CacheReader.getRecordedFragmentLength( cachedFile );
            }

            // create a stereo WAV file w/ the specified properties
            if ( !aFileName.contains( ".wav" ) && !aFileName.contains( "." ))
                aFileName = aFileName + ".wav";

            output = WavFile.newWavFile( FileSystem.open( aFileName ), 2, numSamples, 16, sampleRate );

            final int bufferLength = AudioRenderer.BUFFER_SIZE;

            // create a local buffer
            double[][] localBuffer = new double[ 2 ][ bufferLength ];

            int frameCounter     = 0;
            int recordingPointer = 0;

            while ( frameCounter < numSamples )
            {
                final String theCacheFile  = aCachedFiles[ recordingPointer ];
                final double[][] theBuffer = CacheReader.readRecordedFragment( theCacheFile );

                // we immediately clear the cache file so we have space on the device for writing the WAV sequence!
                FileSystem.delete( theCacheFile );

                for ( final double[] bufferFragment : theBuffer )
                {
                    final long remaining  = output.getFramesRemaining();
                    final int writeAmount = ( remaining > bufferLength ) ? bufferLength : ( int ) remaining;

                    /* the input buffer is (currently) a mono signal, we
                       use the temporary local buffer to write the signal to
                       two sides of the stereo field for stereo output */

                    System.arraycopy( bufferFragment, 0, localBuffer[ 0 ], 0, writeAmount );
                    System.arraycopy( bufferFragment, 0, localBuffer[ 1 ], 0, writeAmount );

                    // write into file
                    output.writeFrames( localBuffer, writeAmount );

                    // update current write pointer
                    frameCounter += writeAmount;
                }
                // update the pointer
                ++recordingPointer;
            }
            // close the file
            output.close();
        }
        catch ( Exception e ) {}

        return output;
    }
}
