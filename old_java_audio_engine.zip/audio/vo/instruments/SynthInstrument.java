package nl.igorski.lib.audio.vo.instruments;

import nl.igorski.lib.audio.factories.ProcessorFactory;
import nl.igorski.lib.audio.vo.chains.ProcessingChain;
import nl.igorski.lib.audio.definitions.WaveForms;
import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.LFO;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 22-04-12
 * Time: 13:28
 * To change this template use File | Settings | File Templates.
 */
public final class SynthInstrument
{
    /* variables used by the SynthEvent class */

    public int waveform;

    public int octave;

    public int keyboardOctave;

    // envelopes ( max value 1 )

    public double attack;

    public double release;

    public double volume;

    public double keyboardVolume;

    // secondary route-able oscillator

    public LFO lfo2;

    public IProcessor lfoDestination;

    public double lfo2speed;

    public int lfo2wave;

    /* variables used by the AudioRenderer class */

    public ProcessingChain processingChain;

    public SynthInstrument()
    {
        // default values
        octave          = 4;
        keyboardOctave  = 4;
        attack          = 0.01;
        release         = 0.01;
        volume          = 0.8;
        keyboardVolume  = 0.5;
        waveform        = WaveForms.SAWTOOTH;
        lfo2wave        = WaveForms.SINE_WAVE;
        lfo2speed       = LFO.MAX_RATE * .5;

        processingChain = new ProcessingChain();
    }

    /* public */

    /**
     * multiple processors may request a secondary
     * oscillator, this method returns the existing LFO
     * or creates a new one if non-existant
     * @return {LFO}
     */
    public LFO getLFO2()
    {
        if ( lfo2 == null )
            lfo2 = ProcessorFactory.createLFO(this);

        return lfo2;
    }

    public void setWaveForm( int aWaveForm )
    {
        waveform = aWaveForm;
    }

    public void setEnvelopes( double aAttack, double aRelease, double aVolume )
    {
        attack  = aAttack;
        release = aRelease;
        volume  = aVolume;
    }
}
