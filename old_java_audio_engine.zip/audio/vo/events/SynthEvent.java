package nl.igorski.lib.audio.vo.events;

import android.util.Log;
import com.ks.iter1.RingBuffer;
import nl.igorski.lib.audio.definitions.PercussionTypes;
import nl.igorski.lib.audio.interfaces.IAudioEvent;
import nl.igorski.lib.audio.renderer.AudioRenderer;
import nl.igorski.lib.audio.vo.instruments.SynthInstrument;
import nl.igorski.lib.audio.definitions.WaveForms;
import nl.igorski.lib.audio.LFO;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 4/12/12
 * Time: 1:20 PM
 * To change this template use File | Settings | File Templates.
 */
public final class SynthEvent implements IAudioEvent
{
    // used for waveform generation

    private double  _phase;

    private double  _phaseIncr;

    private double  _frequency;

    private int     _type;

    private double  TWO_PI;

    private double  TWO_PI_OVER_SR;

    // specific to Pulse Width Modulation
    private final double pwr = Math.PI / 1.05;

    private final double pwAmp = 0.075;

    // specific to Karplus-Strong synthesis

    private RingBuffer ringBuffer;

    private int ringBufferSize;

    private final float EnergyDecayFactor = 0.990f; // TODO maybe settable ?

    // envelopes

    public double decay;

    public double release;

    public double attack;

    public double volume;

    private int decayStart;

    private int decayIncr;

    private double attackEnv;

    private double attackIncr;

    private int releaseStart;

    private double releaseIncr;

    private double releaseEnv;

    private final double DEFAULT_FADE_DURATION = 64.0;

    private final int DECAY_MULTIPLIER         = 200;

    // oscillators

    private LFO _lfo;

    private int _lfoOffset;

    private double _pwmValue = 0;

    // live synthesis

    public boolean liveSynthesis = false;

    private int _minLength;

    private boolean _hasMinLength;

    private boolean _queuedForDeletion = false;

    // buffer regions

    private int _sampleStart;

    private int _sampleEnd;

    private int _sampleLength;

    // cached buffer
    private double[] _buffer;

    // removal of AudioEvents must occur outside of the
    // cache loop, by activating this boolean we're queuing
    // the SynthEvent for removal

    private boolean _deleteMe = false;

    private boolean _cancel = false; // whether we should cancel caching

    private boolean _completed = false; // whether we're done caching

    // used by view representation

    public int position;

    public double length;

    /**
     * initializes an SynthEvent with very definitive properties to be precached
     * for use in a sequencer context
     *
     * @param aFrequency   {int}    the frequency of the note to synthesize in Hz
     * @param aPosition    {int}    the step position in the sequencer
     * @param aLength      {double} the length in steps the note lasts
     * @param aInstrument  {SynthInstrument} the instruments properties
     */
    public SynthEvent( double aFrequency, int aPosition, double aLength, SynthInstrument aInstrument )
    {
        _type           = aInstrument.waveform;
        _lfo            = aInstrument.lfo2;
        _frequency      = aFrequency;
        _phase          = 0.0;
        position        = aPosition;
        length          = aLength;
        _hasMinLength   = true; // pre cached event has no early cancel
        volume          = aInstrument.volume;
        attack          = aInstrument.attack;
        release         = aInstrument.release;

        // constants used by waveform generators
        TWO_PI          = Math.PI * 2;
        TWO_PI_OVER_SR  = TWO_PI / AudioRenderer.SAMPLE_RATE;

        calculateBuffers();
    }

    /**
     * initializes an SynthEvent to be synthesized live, for a live instrument context
     *
     * @param aFrequency  {int} the frequency of the note to synthesize in Hz
     * @param aInstrument {SynthInstrument}
     */
    public SynthEvent( double aFrequency, SynthInstrument aInstrument )
    {
        liveSynthesis = true;
        setFrequency( aFrequency );

        position      = 0;
        length        = AudioRenderer.BYTES_PER_BEAT;

        // quick releases of the key should at least ring for a 32th note ( TODO: @ 120 bpm )
        _minLength    = ( AudioRenderer.BYTES_PER_BAR / 32 );
        _sampleLength = AudioRenderer.BYTES_PER_BAR;
        _hasMinLength = false;                        // keep track if the min length has been rendered

        _type     = aInstrument.waveform;
        setAttack ( aInstrument.attack );
        //setRelease( aInstrument.release ); // no release envelopes for live synth!

        if ( _type == WaveForms.KARPLUS_STRONG ||
             _type == PercussionTypes.KICK_808 )
            initKarplusStrong();
    }

    /* public */

    public int getSampleLength()
    {
        return _sampleLength;
    }

    public int getSampleStart()
    {
        return _sampleStart;
    }

    public int getSampleEnd()
    {
        return _sampleEnd;
    }

    public boolean deletable()
    {
        return _deleteMe;
    }

    public void setDeletable( boolean value )
    {
        // pre buffered event or rendered min length ? schedule for immediate deletion

        if ( !liveSynthesis || _hasMinLength)
            _deleteMe = value;
        else
            _queuedForDeletion = value;
    }

    public double[] getBuffer()
    {
        return _buffer;
    }

    public double getFrequency()
    {
        return _frequency;
    }

    public void setFrequency( double aFrequency )
    {
        _phase     = 0.0;
        _phaseIncr = aFrequency / AudioRenderer.SAMPLE_RATE;
        _frequency = aFrequency;

        if ( liveSynthesis && _type == WaveForms.KARPLUS_STRONG )
            initKarplusStrong();
    }

    public void updateProperties( int aPosition, double aLength, SynthInstrument aInstrument )
    {
        _type    = aInstrument.waveform;
        _lfo     = aInstrument.lfo2;
        position = aPosition;
        length   = aLength;

        attack   = aInstrument.attack;
        release  = aInstrument.release;

        if ( !_completed )
            _cancel = true;
        else
            calculateBuffers();
    }

    public void calculateBuffers()
    {
        _sampleLength = ( int ) length * AudioRenderer.BYTES_PER_TICK;
        _sampleStart  = position * AudioRenderer.BYTES_PER_TICK;
        _sampleEnd    = _sampleStart + _sampleLength;

        releaseStart  = _sampleLength;

        setDecay  ( 70 );
        setAttack ( attack );
        setRelease( release );

        _buffer    = new double[ _sampleLength ];
        _completed = false;

        if ( _type == WaveForms.KARPLUS_STRONG )
            initKarplusStrong();

        cache();
    }

    public double[] synthesize( int aBufferLength )
    {
        final double[] liveBuffer = new double[ aBufferLength ];

        render( liveBuffer );

        // keep track of the rendered bytes, in case of a key up event
        // we still want to have the sound ring for the minimum period
        // defined in the constructor instead of cut off immediately
        _minLength -= aBufferLength;

        if ( _minLength <= 0 )
        {
            _hasMinLength = true;
            setDeletable( _queuedForDeletion );
        }
        return liveBuffer;
    }

    public double getAttack()
    {
        return attack;
    }

    public void setAttack( double aValue )
    {
        attack = aValue;

        if ( attack > 1 )
            attack = 1;

        // no attack set ? WRONG! let's open a very minimal
        // one to prevent popping during sound start

        else if ( attack == 0 )
            attack = ( DEFAULT_FADE_DURATION / _sampleLength);

        attackIncr = 1 / ( _sampleLength * attack );
        attackEnv  = 0.0;

        // update release envelope as it takes parameters from the attack envelope
        setRelease( release );
    }

    public int getDecay()
    {
        return ( int ) Math.round( decay / DECAY_MULTIPLIER );
    }

    public void setDecay( int aValue )
    {
        if ( aValue == 0 )
            aValue = 105;

        decay = Math.round( aValue * DECAY_MULTIPLIER );

        // some waveforms ( sine, triangle ) can have popping occurring
        // at the end when the sample is cut off at an unfortunate point
        // we prevent this pop occurring by decreasing the decay a few
        // samples before the end of the current waveform

        int fadeLength = 4096;
        decayStart = _sampleLength - fadeLength;
        decayIncr = ( int ) Math.round( decay / fadeLength );
    }

    public double getRelease()
    {
        return release;
    }

    /*
     * release is calculated backwards from the total sample length, by
     * default we set the release at a few samples before the end to
     * prevent a pop occurring when audio suddenly stops / starts */

    public void setRelease( double aValue )
    {
        release = aValue;

        // no release set ? WRONG! let's open a very minimal
        // one to prevent popping during sound end

        if ( release > 1.0 )
        {
            release = 1.0;
        }
        else if ( release == 0 )
        {
            release      = DEFAULT_FADE_DURATION / _sampleLength;
            releaseStart = _sampleLength;
        }
        else
        {
            releaseStart = ( int ) ( _sampleLength - ( _sampleLength * release ));
        }

        /*
         * if an attack envelope has been set, set the
         * release value to the attack envelope amount
         * for a gradual fade in and out */

        if ( release > DEFAULT_FADE_DURATION && attack > DEFAULT_FADE_DURATION )
        {
            release      = attack;
            releaseStart = ( int ) ( _sampleLength - ( _sampleLength * release ));
            attackIncr   = 1.0 / ( double )( releaseStart );
        }
        final double delta = _sampleLength - releaseStart;

        if ( delta > 0 )
            releaseIncr = 1.0 / delta;
        else
            releaseIncr = 0.0;

        releaseEnv = 1.0;
    }

    public void destroy()
    {
        _buffer = null;
    }

    /* private */

    private void initKarplusStrong()
    {
        // reset previous ringBuffer data
        ringBufferSize = ( int ) ( AudioRenderer.SAMPLE_RATE / _frequency );
        ringBuffer     = new RingBuffer( ringBufferSize );

        // fill the ring buffer with noise ( initial "pluck" of the "string" )
        for ( int i = 0; i < ringBufferSize; i++ )
            ringBuffer.enqueue( Math.random());
    }

    private void cache()
    {
        // we improve the use of the CPU resources
        // by creating a small local thread
        new Thread(
        new Runnable()
        {
            public void run()
            {
                render( _buffer );
            }
        }).start();
    }

    /**
     * the actual synthesizing of the audio
     *
     * @param aOutputBuffer {double[]} the buffer to write into
     */
    private void render( double[] aOutputBuffer )
    {
        int bufferLength = aOutputBuffer.length;

        double amp = 0.0;
        double tmp, am, dpw;

        // following waveforms require alternate volume multipliers
        final double sawAmp = liveSynthesis ? .7  : 1.0;
        final double swAmp  = liveSynthesis ? .25 : .005;

        for ( int i = 0; i < bufferLength; ++i )
        {
            if ( _cancel ) // stop caching when cancel is requested
                break;

            switch ( _type )
            {
                case WaveForms.SINE_WAVE:

                    // ---- Sine wave

                    // TODO: this pops like a mofo when overlapping sines... diff. implementation ?
                    if ( _phase < .5 )
                    {
                        tmp = ( _phase * 4.0 - 1.0 );
                        amp = ( 1.0 - tmp * tmp );
                    }
                    else {
                        tmp = ( _phase * 4.0 - 3.0 );
                        amp = ( tmp * tmp - 1.0 );
                    }

                    break;

                case WaveForms.SAWTOOTH:

                    // ---- Sawtooth
                    amp = ( _phase < 0 ) ? _phase - ( int )( _phase - 1 ) : _phase - ( int )( _phase );
                    amp *= sawAmp;

                    break;

                case WaveForms.SQUARE_WAVE:

                    // ---- Square wave
                    if ( _phase < .5 )
                    {
                        tmp = TWO_PI * ( _phase * 4.0 - 1.0 );
                        amp = ( 1.0 - tmp * tmp );
                    }
                    else {
                        tmp = TWO_PI * ( _phase * 4.0 - 3.0 );
                        amp = ( tmp * tmp - 1.0 );
                    }
                    amp *= swAmp; // these get loud
                    break;

                case WaveForms.TRIANGLE:

                    // ---- triangle
                    if ( _phase < .5 )
                    {
                        tmp = ( _phase * 4.0 - 1.0 );
                        amp = ( 1.0 - tmp * tmp ) * .75;
                    }
                    else {
                        tmp = ( _phase * 4.0 - 3.0 );
                        amp = ( tmp * tmp - 1.0 ) * .75;
                    }
                    // the actual triangulation function ( at 25 x the speed of the slow Math.abs function )
                    amp = amp < 0 ? -amp : amp;

                    break;

                case WaveForms.PWM:

                    // --- pulse width modulation
                    final double pmv = i + ( ++_pwmValue ); // i + event position

                    dpw = Math.sin( pmv / 0x4800 ) * pwr; // LFO -> PW
                    amp = _phase < Math.PI - dpw ? pwAmp : -pwAmp;

                    // PWM has its own phase update operation
                    _phase = _phase + ( TWO_PI_OVER_SR * _frequency );
                    _phase = _phase > TWO_PI ? _phase - TWO_PI : _phase;
                    am = Math.sin( pmv / 0x1000 ); // LFO -> AM

                    // we multiply the amplitude as PWM results in a "quieter" wave
                    amp *= ( am * 2.5 );
                    break;

                case WaveForms.NOISE:

                    // --- noise
                    if ( _phase < .5 )
                    {
                        tmp = ( _phase * 4.0 - 1.0 );
                        amp = ( 1.0 - tmp * tmp );
                    }
                    else {
                        tmp = ( _phase * 4.0 - 3.0 );
                        amp = ( tmp * tmp - 1.0 );
                    }
                    // above we calculated pitch, now we add some
                    // randomization to the signal for the actual noise
                    amp *= Math.random();
                    break;

                case WaveForms.KARPLUS_STRONG:

                    // --- Karplus-Strong algorithm for plucked string-sound
                    ringBuffer.enqueue(( EnergyDecayFactor * (( ringBuffer.dequeue() + ringBuffer.peek()) / 2 )));
                    amp = ringBuffer.peek() * .7; // get the level down a bit, 'tis loud

                    break;
            }
            // -- general wave operations:
            // envelopes
            if ( attack > 0 )
            {
                if ( attackEnv < 1 )
                {
                    attackEnv += attackIncr;
                    amp       *= attackEnv;
                }
            }
            if ( release > 0 && !liveSynthesis )
            {
                if ( i >= releaseStart )
                {
                    releaseEnv -= releaseIncr;
                    amp        *= releaseEnv;
                }
            }

            // --- _phase update operations
            if ( _type != WaveForms.PWM || liveSynthesis )
            {
                _phase += _phaseIncr;

                // restore _phase, max range is 0 - 1 ( double )
                if ( _phase > 1 )
                    _phase = 0.0;
            }
            // -- write the output into the buffer
            try
            {
                aOutputBuffer[ i ] = amp * volume;
            }
            catch ( NullPointerException e )
            {
                // it might occur that the buffer is wiped for
                // a forced recalculation of this SynthEvent, if so
                // catch this and break the Render loop
                Log.d( "SYNTH", "CAUGHT EXCEPTION DURING RENDER !!" );
                break;
            }
        }
        if ( !liveSynthesis )
            _completed = true;

        // cancel requested ? re-cache to
        // match the new properties (cancel may only
        // be requested when changing properties!)
        if ( _cancel && !liveSynthesis )
        {
            _cancel = false;
            calculateBuffers();
        }
    }
}
