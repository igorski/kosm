package nl.igorski.lib.audio.vo.chains;

import nl.igorski.lib.audio.definitions.AudioConstants;
import nl.igorski.lib.audio.definitions.DistortionTypes;
import nl.igorski.lib.audio.interfaces.IBusProcessor;
import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.processors.*;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 22-04-12
 * Time: 13:29
 * To change this template use File | Settings | File Templates.
 */
public final class ProcessingChain
{
    public FrequencyModulator fm;

    /* filter properties */

    public double filterCutoff;

    public double filterResonance;

    public int filterFormant;

    public Filter filter;

    public FormantFilter formant;

    /* distortion properties */

    public double distortion;

    public double distortionLevel;

    public int distortionType; // we only allow ONE distortion at a time

    public WaveShaper waveShaper;

    public BitCrusher bitCrusher;

    /* delay properties */

    public double delayTime;

    public double delayMix;

    public double delayFeedback;

    public Delay delay;

    /* cached chains */

    private Vector<IProcessor> _activeProcessors;

    private Vector<IBusProcessor> _activeBusProcessors;

    public ProcessingChain()
    {
        filterCutoff    = AudioConstants.FILTER_MAX_FREQ * .5;
        filterResonance = AudioConstants.FILTER_MAX_RESONANCE * .5;
        filterFormant   = 0;

        delayTime       = 250;
        delayMix        = .25;
        delayFeedback   = .5;

        distortion      = .5;
        distortionLevel = .5;
        distortionType  = DistortionTypes.BIT_CRUSHER;

        _activeProcessors    = new Vector<IProcessor>();
        _activeBusProcessors = new Vector<IBusProcessor>();
    }

    /* public */

    public void cacheActiveProcessors()
    {
        _activeProcessors = new Vector<IProcessor>();

        if ( fm != null )
            _activeProcessors.add( fm );

        if ( waveShaper != null )
            _activeProcessors.add( waveShaper );

        if ( bitCrusher != null )
            _activeProcessors.add( bitCrusher );

        if ( filter != null )
            _activeProcessors.add( filter );

        if ( formant != null )
            _activeProcessors.add( formant );

        // bus processors
        _activeBusProcessors = new Vector<IBusProcessor>();

        if ( delay != null )
            _activeBusProcessors.add( delay );
    }

    public Vector<IProcessor> getActiveProcessors()
    {
        return _activeProcessors;
    }

    public Vector<IBusProcessor> getActiveBusProcessors()
    {
        return _activeBusProcessors;
    }
}
