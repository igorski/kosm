package nl.igorski.lib.audio.vo;

import nl.igorski.lib.audio.interfaces.IAudioEvent;
import nl.igorski.lib.audio.vo.chains.ProcessingChain;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 01-06-12
 * Time: 09:45
 * To change this template use File | Settings | File Templates.
 */
public final class AudioChannel
{
    public Vector<IAudioEvent> audioEvents;

    public Vector<IAudioEvent> liveEvents;

    public boolean hasLiveEvents;

    public ProcessingChain processingChain;

    public double mixVolume;

    /**
     * an AudioChannel may contain audio that spans a different
     * buffer range than the other channels in a Sequencer
     * (for instance: a looping one bar drum pattern over
     * four bars of synthesis)
     *
     * specify a max buffer position for the AudioChannel
     * to have the AudioRenderer loop its contents while
     * processing the whole buffer range for the other channels
     *
     * if the max buffer position is equal to the sequencer
     * max range, pass no value or 0 for maxBufferPosition
     */
    public int maxBufferPosition;

    public AudioChannel( Vector<IAudioEvent> aAudioEvents, ProcessingChain aChain, double aMixVolume )
    {
        audioEvents       = aAudioEvents;
        processingChain   = aChain;
        mixVolume         = aMixVolume;
        maxBufferPosition = 0;
    }

    public AudioChannel( Vector<IAudioEvent> aAudioEvents, ProcessingChain aChain, double aMixVolume, int aMaxBufferPosition )
    {
        audioEvents       = aAudioEvents;
        processingChain   = aChain;
        mixVolume         = aMixVolume;
        maxBufferPosition = aMaxBufferPosition;
    }

    /* public */

    /**
     * a channel can both contain buffered output as well
     * as live events ( for instance a keyboard plays the
     * same synthesizer as the sequenced patterns ). We need to
     * add them here so they can benefit from the same processing chain
     *
     * @param aLiveEvents {Vector<IAudioEvent>} the live events
     */
    public void addLiveEvents( Vector<IAudioEvent> aLiveEvents )
    {
        hasLiveEvents = true;
        liveEvents    = aLiveEvents;
    }
}
