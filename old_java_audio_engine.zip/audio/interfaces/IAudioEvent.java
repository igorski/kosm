package nl.igorski.lib.audio.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 01-06-12
 * Time: 13:02
 * To change this template use File | Settings | File Templates.
 * an IAudioEvent describes a sample of audio
 * with its unique properties and can render
 * it into a buffer which can be written into
 * the audio streams output buffer by the AudioRenderer
 */
public interface IAudioEvent
{
    /* public methods */

    /**
     * an IAudioEvent contains a buffer holding the samples, this
     * is used by the AudioRenderer to write the samples into the output buffer
     * @return {double[]} the buffer containing this events samples
     */
    public double[] getBuffer();

    /**
     * an IAudioEvent can also synthesize audio live, this
     * method should be called during the write cycle on
     * each buffer update of the AudioRenderer
     * @param aBufferLength {int} desired buffer length ( usually buffer size )
     * @return {double[]} the buffer containg the live generated samples
     */
    public double[] synthesize( int aBufferLength );

    public int getSampleLength();
    public int getSampleStart();
    public int getSampleEnd();

    public boolean deletable(); // are we queued for deletion ?
    public void setDeletable( boolean value );

    public void destroy();
}
