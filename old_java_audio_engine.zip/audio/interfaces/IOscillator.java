package nl.igorski.lib.audio.interfaces;

import org.json.JSONObject;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 20-04-12
 * Time: 09:52
 * To change this template use File | Settings | File Templates.
 */
public interface IOscillator
{
    public void generate( int aLength );
    public JSONObject getData();

    public double getRate();
    public void setRate( double value );

    public String getWave();
    public void setWave( String value );
}
