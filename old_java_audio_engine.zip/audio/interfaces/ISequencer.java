package nl.igorski.lib.audio.interfaces;

import nl.igorski.lib.audio.vo.AudioChannel;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 6/8/12
 * Time: 5:17 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ISequencer
{
    /**
     * an ISequencer is the interface feeding the AudioRenderer the
     * events and properties used for audio output
     */

    /**
     * return the AudioEvents that should be rendered for the current positions
     * @param bufferPosition     {int} current buffer position
     * @param bufferEnd          {int} end position for the current buffer (start position plus buffer size)
     * @param addLiveInstruments {boolean} whether the Vector should contain instruments that are rendered live
     *
     * @return {Vector<AudioChannel>}
     */
    public Vector<AudioChannel> getAudioEvents( int bufferPosition, int bufferEnd, boolean addLiveInstruments );

    /**
     * Sequencers can have different properties, return the
     * amount of time intervals within a bar (for instance 16
     * for creation of 16th notes, 32, 64, 128 )
     *
     * @return {int}
     */
    public int getStepsPerBar();

    /**
     * how many measures / bars are
     * mapped in the sequencer ?
     * @return {int}
     */
    public int getMeasures();

    /**
     * A sequencer's tempo is linked to a AudioRenderer as
     * the renderer must invoke the tempo update outside of
     * its read / render cycles
     *
     * Typical behaviour for handling an update in tempo is
     * altering view states / updating AudioEvents
     */
    public void handleTempoUpdate();

    /**
     * Every tick (each step in a bar) that has passed, invokes
     * this method in the sequencer. Likely for updating views
     *
     * @param aPosition {int}
     */
    public void handleSequencerPositionUpdate( int aPosition );

    /**
     * There is a set interval for recording live output
     * where the recorded buffer is passed for writing to disk, this
     * should overcome unnecessarily large memory allocation while recording
     */
    public void handleRecordingUpdate( double[][] aRecording );
}
