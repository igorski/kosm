package nl.igorski.lib.audio.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 20-04-12
 * Time: 09:49
 * To change this template use File | Settings | File Templates.
 */
public interface IBusProcessor
{
    /**
     * a bus processor differs from an IProcessor
     * as it adds the result of the process method
     * to the current sampleBuffer, whereas a common
     * IProcessor replaces the input with the
     * processed output
     *
     * the IBusProcessor is applied during the rendering
     * of all audioEvents
     *
     * NOTE: the input sampleBuffer has been optimized
     * to shorts at this point
     *
     * @param sampleBuffer {double[]} the current buffer
     */
    public void apply( double[] sampleBuffer );
}
