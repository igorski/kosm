package nl.igorski.lib.audio.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 19-04-12
 * Time: 22:48
 * To change this template use File | Settings | File Templates.
 */
public interface IProcessor
{
    /**
     * the IProcessor is applied during the initial
     * rendering of a single SynthEvent as its output
     * replaces the initial audio input
     *
     * @param sampleBuffer {double[]}
     */
    public void process( double[] sampleBuffer );
}
