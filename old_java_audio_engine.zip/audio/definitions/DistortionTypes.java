package nl.igorski.lib.audio.definitions;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 5/25/12
 * Time: 3:23 PM
 * To change this template use File | Settings | File Templates.
 */
public final class DistortionTypes
{
    public static final int WAVE_SHAPER = 0;
    public static final int BIT_CRUSHER = 1;
}
