package nl.igorski.lib.audio.definitions;

import nl.igorski.lib.audio.renderer.AudioRenderer;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 22-04-12
 * Time: 14:21
 * To change this template use File | Settings | File Templates.
 *
 * constants used by the engine, as the variables
 * are static you can override these should you desire
  */
public final class AudioConstants
{
    /* octave range */

    public static int MIN_OCTAVE                = 1;
    public static int MAX_OCTAVE                = 8;

    /* filter frequency ranges */

    public static double FILTER_MIN_FREQ        = 50;
    public static double FILTER_MAX_FREQ        = AudioRenderer.SAMPLE_RATE * .5;
    public static double FILTER_MIN_RESONANCE   = 0.1;
    public static double FILTER_MAX_RESONANCE   = Math.sqrt( 2 ) * .5;

    /* oscillator destinations */

    public static final int LFO_DESTINATION_FILTER    = 0;
    public static final int LFO_DESTINATION_FM        = 1;

    /* user interface related */

    public static final int ROTARY_UPDATE_DELAY = 500; // milliseconds
}
