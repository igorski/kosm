package nl.igorski.lib.audio.definitions;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 01-06-12
 * Time: 19:09
 * To change this template use File | Settings | File Templates.
 */
public final class PercussionTypes
{
    public static final int KICK_808 = 10;
    public static final int STICK    = 11;
    public static final int SNARE    = 12;
    public static final int HI_HAT   = 13;
}
