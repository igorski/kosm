package nl.igorski.lib.audio.definitions;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 20-04-12
 * Time: 10:20
 * To change this template use File | Settings | File Templates.
 */
public final class WaveForms
{
    public static final int SINE_WAVE       = 0;
    public static final int TRIANGLE        = 1;
    public static final int SAWTOOTH        = 2;
    public static final int SQUARE_WAVE     = 3;
    public static final int NOISE           = 4;
    public static final int PWM             = 5;
    public static final int KARPLUS_STRONG  = 6;
}
