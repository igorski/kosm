package nl.igorski.lib.audio.renderer;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;
import nl.igorski.lib.audio.helpers.BufferCalculator;
import nl.igorski.lib.audio.interfaces.IAudioEvent;
import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.interfaces.ISequencer;
import nl.igorski.lib.audio.processors.Finalizer;
import nl.igorski.lib.audio.processors.LPFHPFilter;
import nl.igorski.lib.audio.processors.Limiter;
import nl.igorski.lib.audio.utils.BufferCloner;
import nl.igorski.lib.audio.vo.AudioChannel;
import nl.igorski.lib.audio.vo.chains.ProcessingChain;
import nl.igorski.lib.utils.threading.BaseThread;
import nl.igorski.lib.audio.interfaces.IBusProcessor;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 10-04-12
 * Time: 20:16
 * To change this template use File | Settings | File Templates.
 */
public final class AudioRenderer extends BaseThread
{
    private boolean _playing       = false;

    private ISequencer _sequencer;  // reference to the Sequencer containing all AudioEvents

    /* audio generation related */

    public static final int LOW_QUALITY     = 11025;
    public static final int MEDIUM_QUALITY  = 22050;
    public static final int HIGH_QUALITY    = 44100;

    public static final int SAMPLE_RATE  = HIGH_QUALITY;
    public static final int BUFFER_SIZE  = AudioTrack.getMinBufferSize( SAMPLE_RATE,
                                           AudioFormat.CHANNEL_CONFIGURATION_MONO,
                                           AudioFormat.ENCODING_PCM_16BIT );

    private final int       NUM_SAMPLES  = BUFFER_SIZE; // live stream, so no need to exceed buffer size
    private final double    sample[]     = new double[ NUM_SAMPLES ];
    private double silence[]             = null;

    private double _tempo;

    private double _tempoQueued;

    // we CAN multiply the output the volume to decrease it, preventing rapidly distorting audio ( especially on filters )

    private static final double VOLUME_MULTIPLIER = 1;

    private static double _volume = .85 /* assumed default level */ * VOLUME_MULTIPLIER;

    private Finalizer _limiter;
    private LPFHPFilter _hpf;

    // we make these available across classes

    public static int BYTES_PER_SAMPLE          = 8;
    public static int BYTES_PER_BEAT;
    public static int BYTES_PER_BAR;
    public static int BYTES_PER_TICK;
    public static int AMOUNT_OF_VOICES          = 1; // in case we feel adventurous and extend this...

    // private variables for updating buffer positions according to the amount of measures in the sequencer

    private int AMOUNT_OF_BARS                  = 1;
    private int MIN_BUFFER_POSITION             = 0; // initially 0, but can differ when looping certain measures
    private int MAX_BUFFER_POSITION             = 0;
    private int MIN_STEP_POSITION;
    private int MAX_STEP_POSITION;

    private final byte generatedSnd[] = new byte[ 2 * NUM_SAMPLES];

    private final AudioTrack _audioTrack = new AudioTrack( AudioManager.STREAM_MUSIC,
                                           SAMPLE_RATE, AudioFormat.CHANNEL_CONFIGURATION_MONO,
                                           AudioFormat.ENCODING_PCM_16BIT, NUM_SAMPLES,
                                           AudioTrack.MODE_STREAM );

    /* buffer read/write pointers */

    private int _bufferPosition = 0;
    private int _stepPosition   = 0;

    /* recording buffer specific */

    private boolean _recordOutput   = false;
    private int _maxRecordBuffers   = 0;
    private int _recordWritePointer = 0;
    private double[][] _recordedOutput;

    /* bus processors */
    private Vector<IBusProcessor> busProcessors;

    /**
     * AudioRenderer synthesizes all audio
     * created in the sequencer
     *
     * @param aSequencer {ISequencer} the sequencer containing
     *        all the audio events to be synthesized
     */
    public AudioRenderer( ISequencer aSequencer )
    {
        _sequencer        = aSequencer;
        MIN_STEP_POSITION = 0;
        MAX_STEP_POSITION = _sequencer.getStepsPerBar();

        // set default BPM
        setTempo( 120 );
        doTempoUpdate( _tempoQueued );

        setPriority( MAX_PRIORITY );
        init();
    }

    /* public */

    public void setPlaying( boolean value )
    {
        _playing = value;
    }

    public double getTempo()
    {
        return _tempo;
    }

    public void setTempo( double aValue )
    {
        _tempoQueued = aValue;
    }

    public double getVolume()
    {
        return _volume / VOLUME_MULTIPLIER;
    }

    public void setVolume( double aValue )
    {
        _volume = aValue * VOLUME_MULTIPLIER;
    }

    public void updateMeasures( int aValue )
    {
        AMOUNT_OF_BARS      = aValue;
        MAX_STEP_POSITION   = _sequencer.getStepsPerBar() * AMOUNT_OF_BARS;
        MAX_BUFFER_POSITION = BYTES_PER_BAR * AMOUNT_OF_BARS;
    }

    public void setRecordingState( boolean value )
    {
        // create / reset the recorded buffer when
        // hitting the record button
        if ( value )
        {
            clearRecording();

            // we record a maximum of 30 seconds before invoking the "handleRecordingUpdate"-method on the sequencer
            final double amountOfMinutes = .5;
            final int bufferSize         = BufferCalculator.millisecondsToBuffer(( int )  ( amountOfMinutes * 60000 ), SAMPLE_RATE );

            _maxRecordBuffers   = bufferSize / BUFFER_SIZE;
            _recordWritePointer = 0;
            _recordedOutput     = new double[ _maxRecordBuffers ][];
        }
        _recordOutput = value;
    }

    public boolean getRecordingState()
    {
        return _recordOutput;
    }

    public double[][] getRecording()
    {
        return _recordedOutput;
    }

    public void clearRecording()
    {
        // let's instruct the garbage collector we don't need to reference this data anymore
        //if ( _recordedOutput != null )
        //_recordedOutput.clear();

        _recordedOutput = new double[ _maxRecordBuffers ][];
    }

    /**
     * define a range for the sequencer to loop
     * @param aStartPosition {int} step position of the start point
     * @param aEndPosition   {int} step position of the end point
     */
    public void setLoopPoint( int aStartPosition, int aEndPosition )
    {
        MIN_BUFFER_POSITION = aStartPosition;
        MAX_BUFFER_POSITION = aEndPosition;

        if ( _bufferPosition < MIN_BUFFER_POSITION || _bufferPosition > MAX_BUFFER_POSITION )
            _bufferPosition = MIN_BUFFER_POSITION;

        final int stepsPerBar = _sequencer.getStepsPerBar();

        MIN_STEP_POSITION = ( aStartPosition / BYTES_PER_BAR ) * stepsPerBar;
        MAX_STEP_POSITION = ( aEndPosition / BYTES_PER_BAR ) * stepsPerBar;

        if ( _stepPosition < MIN_STEP_POSITION || _stepPosition > MAX_STEP_POSITION )
            _stepPosition =  MIN_STEP_POSITION;
    }

    /**
     * get the sequencers current position (is a step point
     * between the sequencers loop range), we should never
     * return buffer positions as it is the AudioRenderers
     * job to handle these
     *
     * @return {int}
     */
    public int getPosition()
    {
        return _stepPosition;
    }

    @Override
    public void start()
    {
        _playing = true;

        if ( _audioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING )
            _audioTrack.play();

        super.start();
    }

    public void run()
    {
        while ( _isRunning )
        {
            if ( _playing )
            {
                // gather the audio events by the buffer range currently being processed
                try
                {
                    int endPosition = _bufferPosition + BUFFER_SIZE;

                    Vector<AudioChannel> channels = _sequencer.getAudioEvents( _bufferPosition, endPosition, true );

                    // read pointer exceeds maximum size ? => sequencer has started its loop, gather remainder at start position
                    if ( endPosition > MAX_BUFFER_POSITION )
                    {
                        endPosition -= MAX_BUFFER_POSITION;
                        channels.addAll( _sequencer.getAudioEvents( MIN_BUFFER_POSITION, endPosition, false ));
                    }
                    renderAudio( channels );
                }
                catch ( Exception e )
                {
                    // most likely removal of events being processed...
                    Log.d( "SYNTH", "AudioRenderer::CAUGHT " + e.getMessage());
                }
                catch ( OutOfMemoryError me )
                {
                    Log.d( "SYNTH", "OUT OF MEMORY CAUGHT" );

                    setRecordingState( false );
                    clearRecording();
                }
            }
            else
            {
                // thread sleep to prevent CPU hogging
                try
                {
                    sleep( 1000 );
                }
                catch( InterruptedException e ) {}
            }
            synchronized ( _pauseLock )
            {
                while ( _paused )
                {
                    try {
                        _pauseLock.wait();
                    }
                    catch ( InterruptedException e ) {}
                }
            }
        }
    }

    /* event handlers */

    // ...

    /* private */

    private void renderAudio( Vector<AudioChannel> audioChannels )
    {
        // generate silence
        System.arraycopy( silence, 0, sample, 0, BUFFER_SIZE );

        for ( final AudioChannel channel : audioChannels )
        {
            final Vector<IAudioEvent> audioEvents = channel.audioEvents;
            final int amount                      = audioEvents.size();

            final double channelBuffer[] = new double[ NUM_SAMPLES ];
            final int maxBufferPosition  = ( channel.maxBufferPosition != 0 ) ? channel.maxBufferPosition : MAX_BUFFER_POSITION;

            // we make a copy of the current buffer position indicator
            int bufferPosition = _bufferPosition;

            // ...in case the AudioChannels maxBufferPosition differs from the sequencer max ( this class's MAX_BUFFER_POSITION )
            while ( bufferPosition >= maxBufferPosition )
                bufferPosition -= BYTES_PER_BAR;

            if ( amount > 0 )
            {
                //final double amp = ( 1 / ( double ) amount ) * mix; // normalization of audio, creates nasty DC offsets!
                final double amp = _volume;

                // write the audioEvent buffers into the main output buffer
                for ( final IAudioEvent vo : audioEvents )
                {
                    // read from a pre-cached buffer for sequenced notes
                    // first we cache references to the AudioEvents properties
                    final double[] buffer  = vo.getBuffer();
                    final int startOffset  = vo.getSampleStart();
                    final int endOffset    = vo.getSampleEnd();
                    final int sampleLength = vo.getSampleLength();

                    for ( int i = 0; i < NUM_SAMPLES; ++i )
                    {
                        int readPointer = i + bufferPosition;

                        // over the max position ? read from the start ( sequence has started its loop )
                        if ( readPointer >= maxBufferPosition )
                            readPointer = i;

                        if ( readPointer >= startOffset && readPointer <= endOffset )
                        {
                            // mind the offset ! ( cached buffer starts at 0 while
                            // the startOffset defines where the event is positioned in the sequencer )
                            readPointer -= startOffset;

                            if ( readPointer == sampleLength )
                                break;

                            try
                            {
                                channelBuffer[ i ] += ( buffer[ readPointer ] * amp );
                            }
                            catch( ArrayIndexOutOfBoundsException e )
                            {
                                break;
                            }
                        }
                    }
                }
            }
            // perform live rendering for this instrument
            if ( channel.hasLiveEvents )
            {
                final int lAmount = channel.liveEvents.size();
                final double lAmp = ( lAmount == 1 ) ? _volume : ( 1.0 / ( lAmount - 1.0 )) * _volume;

                for ( final IAudioEvent vo : channel.liveEvents )
                {
                    final double[] buffer = vo.synthesize( BUFFER_SIZE );

                    for ( int i = 0; i < NUM_SAMPLES; ++i )
                    {
                        channelBuffer[ i ] += buffer[ i ] * lAmp;
                    }
                }
            }
            // apply the processing chain
            final ProcessingChain chain = channel.processingChain;

            // apply processors / modulators
            final Vector<IProcessor> processors = chain.getActiveProcessors();

            for ( final IProcessor processor : processors )
                processor.process( channelBuffer );

            // apply bus processors
            final Vector<IBusProcessor> bus = chain.getActiveBusProcessors();

            for ( final IBusProcessor processor : bus )
                    processor.apply( channelBuffer );

            // write the channel buffer into the combined output buffer, apply channel volume
            for ( int i = 0; i < NUM_SAMPLES; ++i )
            {
                sample[ i ] += ( channelBuffer[ i ] * channel.mixVolume );
            }
        }
        // apply high pass filtering to prevent extreme low rumbling and nasty filter offsets
        _hpf.process( sample );

        // apply the busProcessors to the combined output
        if ( busProcessors.size() > 0 )
        {
            for ( final IBusProcessor p : busProcessors)
                p.apply( sample );
        }

        // limit the audio to prevent clipping, the limiter also converts
        // the double samples to an Array of shorts
        final short[] output = _limiter.process( sample );

        // update the buffer pointers
        for ( int i = 0; i < BUFFER_SIZE; ++i )
        {
            ++_bufferPosition;

            if ( _bufferPosition > MAX_BUFFER_POSITION )
                _bufferPosition = MIN_BUFFER_POSITION;
        }

        // write the buffer into the AudioTrack
        _audioTrack.write( output, 0, BUFFER_SIZE );

        // tempo updates must be processed outside of the read cycle!
        if ( _tempoQueued != _tempo )
        {
            doTempoUpdate( _tempoQueued );
            _sequencer.handleTempoUpdate();
        }

        // record the output
        if ( _recordOutput )
        {
            final double[] b = new double[ NUM_SAMPLES ];
            for ( int i = 0; i < NUM_SAMPLES; ++i )
            {
                double s = sample[ i ];

                // limiting (still above the thresholds?)
                if ( s < -1.0 )
                    s = -1.0;

                else if ( s > +1.0 )
                    s = +1.0;

                b[ i ] = s;
            }
            _recordedOutput[ _recordWritePointer ] = b;

            // exceeded maximum recording buffer > write buffer
            if ( ++_recordWritePointer >= _maxRecordBuffers )
            {
                _sequencer.handleRecordingUpdate( BufferCloner.cloneRecording( _recordedOutput ));

                // clear recorded buffer so we can continue writing
                _recordWritePointer = 0;
                clearRecording();
            }
        }
    }

    private void init()
    {
        // create empty buffer (quickly copied for "silence" when resetting main output buffer)
        silence = new double[ NUM_SAMPLES ];

        for ( int i = 0; i < BUFFER_SIZE; ++i )
        {
            silence[ i ] = 0.0;
        }

        _audioTrack.setPlaybackRate( SAMPLE_RATE );
        _audioTrack.play(); // play before writing when using MODE_STREAM
        addProgressListeners();

        busProcessors = new Vector<IBusProcessor>();

        _limiter  = new Finalizer( 2, 500, SAMPLE_RATE );
        _hpf      = new LPFHPFilter( SAMPLE_RATE, 200 );
    }

    private void addProgressListeners()
    {
        _audioTrack.setPositionNotificationPeriod( BUFFER_SIZE );
        _audioTrack.setPlaybackPositionUpdateListener( new AudioTrack.OnPlaybackPositionUpdateListener()
        {
            // we update the sequencer's VISUAL position using
            // this event handler as the ACTUAL position used by
            // the render method above is out of sync with the
            // view render thread

            public void onPeriodicNotification( AudioTrack track )
            {
                int playbackPos = _audioTrack.getPlaybackHeadPosition();

                for ( int i = 0; i < BUFFER_SIZE; ++i )
                {
                    if ( ++playbackPos % BYTES_PER_TICK == 0 )
                    {
                        ++_stepPosition;

                        // larger-equal check as we can remove measures from the sequencer while running
                        if ( _stepPosition >= MAX_STEP_POSITION )
                            _stepPosition = MIN_STEP_POSITION;

                        _sequencer.handleSequencerPositionUpdate( _stepPosition );
                        //_sequencer.handleSequencerPositionUpdate( Math.round(( _audioTrack.getPlaybackHeadPosition() /*+ _latency */) / BYTES_PER_TICK ) - 1 );
                    }
                }
            }
            public void onMarkerReached( AudioTrack track )
            {
                // won't happen in a continuous stream
            }
        });
    }

    private void doTempoUpdate( double value )
    {
        _tempo              = value;
        BYTES_PER_BEAT      = ( int ) Math.round(( SAMPLE_RATE * 60 ) / value );

        // this sequencer works within a sixteen notes per bar context
        // the bytes per tick defines the bytes per sixteenth notes

        BYTES_PER_TICK      = ( int ) ( BYTES_PER_BEAT * .25 );
        BYTES_PER_BAR       = BYTES_PER_BEAT * 4;

        MAX_BUFFER_POSITION = BYTES_PER_BAR * AMOUNT_OF_BARS;
    }
}
