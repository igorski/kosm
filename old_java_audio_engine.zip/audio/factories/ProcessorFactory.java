package nl.igorski.lib.audio.factories;

import nl.igorski.lib.audio.definitions.AudioConstants;
import nl.igorski.lib.audio.processors.*;
import nl.igorski.lib.audio.renderer.AudioRenderer;
import nl.igorski.lib.audio.vo.chains.ProcessingChain;
import nl.igorski.lib.audio.vo.instruments.SynthInstrument;
import nl.igorski.lib.audio.definitions.WaveForms;
import nl.igorski.lib.audio.LFO;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 5/1/12
 * Time: 4:44 PM
 * To change this template use File | Settings | File Templates.
 *
 * Factory used to open I(Bus)Processors, all new instances
 * created throughout a application should use this class
 * as the sole creation method to ensure all properties are
 * always initialized in the same manner
 */
public final class ProcessorFactory
{
    public static Delay createDelay( ProcessingChain chain )
    {
        return new Delay( chain.delayTime,
                          chain.delayMix,
                          chain.delayFeedback );
    }

    public static Filter createFilter( ProcessingChain chain )
    {
        return new Filter( chain.filterCutoff,
                           chain.filterResonance,
                           AudioConstants.FILTER_MIN_FREQ,
                           AudioConstants.FILTER_MAX_FREQ,
                           0.0 );
    }

    public static WaveShaper createWaveShaper( ProcessingChain chain )
    {
        return new WaveShaper( chain.distortion, chain.distortionLevel );
    }

    public static BitCrusher createBitCrusher( ProcessingChain chain )
    {
        return new BitCrusher( chain.distortion, chain.distortionLevel );
    }

    public static FormantFilter createFormantFilter( ProcessingChain chain )
    {
        return new FormantFilter( chain.filterFormant );
    }

    /* SynthInstrument specific */

    public static FrequencyModulator createFM( SynthInstrument instrument )
    {
        return new FrequencyModulator( WaveForms.SINE_WAVE,
                                       instrument.lfo2speed,
                                       AudioRenderer.BYTES_PER_BAR );
    }

    public static LFO createLFO( SynthInstrument instrument )
    {
        return new LFO( instrument.lfo2wave,
                        instrument.lfo2speed,
                        AudioRenderer.BYTES_PER_BAR );
    }

    public static Filter createFilter( SynthInstrument instrument )
    {
        Filter filter = createFilter( instrument.processingChain );

        // in case we already had a filter, and it is the current instruments destination
        // for the secondary LFO, we assign the current LFO speed to the new Filter instance
        if ( instrument.lfoDestination != null &&
                instrument.lfoDestination == instrument.processingChain.filter )
        {
            filter.setLFORate( instrument.lfo2speed );
        }
        return filter;
    }
}
