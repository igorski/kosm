package nl.igorski.lib.audio.processors.base;

/**
 * Created with IntelliJ IDEA.
 * User: igorzinken
 * Date: 10/12/12
 * Time: 9:23 AM
 * To change this template use File | Settings | File Templates.
 */

public interface IDynamicsVariables
{
    public void update( int sampleRate );

    public boolean isRMS();

    public double getThreshold(); //  NOT dB, the actual level

    public double getInverseThreshold();

    public double getThresholddB();

    public double getInverseRatio();

    public double getKneedB();

    public double getAttack(); //        NOT ms, the exponential coefficient

    public int getHold(); //    NOT ms, samples

    public double getRelease(); //       NOT ms, the exponential coefficient

    public double getDepth(); // NOT dB, the actual level

    public double getDryGain(); //  NOT dB, the actual gain factor

    public double getGain(); //  NOT dB, the actual static makeup gain

    public double getHysteresis(); //  NOT dB, the actual factor
}
