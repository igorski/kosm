// blatantly stolen from the toot Google code:
// Copyright (C) 2006, 2010 Steve Taylor.
// Distributed under the Toot Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.toot.org.uk/LICENSE_1_0.txt)

package nl.igorski.lib.audio.processors.base;

import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.renderer.AudioRenderer;
import nl.igorski.lib.utils.math.MathTool;

import static uk.org.toot.dsp.FastMath.*;

abstract public class BaseDynamicsProcess extends DynamicsControls implements IProcessor
{
    protected double envelope = 0.0;

    protected boolean isPeak = false;
    protected double threshold;
    protected double attack, release;
    protected double makeupGain, dryGain;

    private boolean wasBypassed;

    private int sampleRate = 0;

    private int NSQUARESUMS = 10;
    private double[] squaresums = new double[ NSQUARESUMS ];
    private int nsqsum = 0;

    // when moving to stereo make these multi-dimensional
    private double[] samples    = new double[]{};
    private double[] tapSamples = new double[]{};
    private double[] keySamples;

    public BaseDynamicsProcess()
    {
        this( false );
    }

    public BaseDynamicsProcess( boolean peak )
    {
        super(( int )( Math.random() * 100 ), "CCTRL" );
        
        this.isPeak = peak;
    }

    /* public methods */

    public void process( double[] sampleBuffer )
    {
        final int sr = AudioRenderer.SAMPLE_RATE;
        if ( sr != sampleRate ) {
            sampleRate = sr;
            update( sr ); // rederives attack, release
        }
        cacheProcessVariables();
        double targetGain = 1.0;       // unity
        double gain      = makeupGain; // keeps compiler happy

        final int len   = sampleBuffer.length;
        final int mslen = sr / 1000;

        // when moving to stereo, use these to iterate over channels
        final int nc  = 0, nck = 1;

        if ( sampleBuffer == null )
        {
            keySamples = samples;
        } else {
            tapSamples = sampleBuffer;
            keySamples = tapSamples;
        }

        double sample;
        for ( int i = 0; i < len; i++ )
        {
            double key = 0;

            if ( isPeak )
            {
                //for ( int c = 0; c < nck; c++ ) {
                key = MathTool.max( key, MathTool.abs( keySamples[ i ]));
                // }
                targetGain = function( key );
            }
            else if (( i % mslen ) == 0 )
            {
                final int length = ( i + mslen ) > len ? len - i : mslen;

                // the RMS side chain calculations, every millisecond
                double sumOfSquares = 0.0;
                // for ( int c = 0; c < nck; c++ ) {
                for ( int j = 0; j < length; j++ )
                {
                    sample        = keySamples/*[c]*/[ i + j ];
                    sumOfSquares += sample * sample;
                }
                //}
                squaresums[ nsqsum ] = sumOfSquares / length;

                double mean = 0;
                for ( int s = 0; s < NSQUARESUMS; s++ ) {
                    mean += squaresums[s];
                }

                if ( ++nsqsum >= NSQUARESUMS )
                    nsqsum = 0;

                key        = sqrt( mean / NSQUARESUMS );
                targetGain = function( key );
            }

            gain = dynamics( targetGain );

            // affect all channels identically to preserve positional image
            //for ( int c = 0; c < nc; c++ ) {
            sampleBuffer/*[c]*/[ i ] *= ( gain * makeupGain ) + dryGain;
            //}
        }
        // we only announce the final value at the end of the buffer
        // this effectively subsamples the dynamic gain
        // but typically attack and release will provide sufficient smoothing
        // for the avoidance of aliasing

        //setDynamicGain( gain );
    }

    public void clear()
    {
        envelope = 1.0; // envelope of gain
        setDynamicGain( 1.0 );
    }

    /* protected methods */

    protected void cacheProcessVariables()
    {
        // update local variables
        threshold  = getThreshold(); // all subclasses use this
        attack     = getAttack();
        release    = getRelease();
        makeupGain = getGain();
        dryGain    = getDryGain();
    }

    // effect of comparison of detected against threshold - subclass issue
    protected abstract double function( double value );

    // hold is a gate subclass issue
    protected double dynamics( double target )
    {
        // anti-denormal not needed, decays to unity
        // seems back to front because (>)0 is max and 1 is min gain reduction
        double factor = target < envelope ?  attack : release;
        return factor * ( envelope - target ) + target;
    }
}
