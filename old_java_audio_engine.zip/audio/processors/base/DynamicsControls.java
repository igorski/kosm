package nl.igorski.lib.audio.processors.base;

import nl.igorski.lib.audio.utils.VolumeUtil;

/**
 * Created with IntelliJ IDEA.
 * User: igorzinken
 * Date: 10/12/12
 * Time: 10:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class DynamicsControls implements IDynamicsVariables
{
//    private final static AbstractLaw THRESH_LAW        = new LinearLaw( -40.0, 20.0,   "dB" );
//    private final static AbstractLaw RATIO_LAW         = new LogLaw   ( 1.5,   10.0,   "" );
//    private final static AbstractLaw INVERSE_RATIO_LAW = new LinearLaw( 1,     -1,     "" );
//    private final static AbstractLaw KNEE_LAW          = new LinearLaw( 0.1,   20.0,   "dB" );
//    private final static AbstractLaw ATTACK_LAW        = new LogLaw   ( 0.1,   100.0,  "ms" );
//    private final static AbstractLaw HOLD_LAW          = new LogLaw   ( 1.0,   100.0, "ms" );
//    private final static AbstractLaw RELEASE_LAW       = new LogLaw   ( 200.0, 2000.0, "ms" );
//    private final static AbstractLaw DRY_GAIN_LAW      = new LinearLaw( -40.0, 0.0,    "dB" );
//    private final static AbstractLaw GAIN_LAW          = new LinearLaw( 0,     20.0,   "dB" );
//    private final static AbstractLaw DEPTH_LAW         = new LinearLaw( -80.0, 0.0,    "dB" );
//    private final static AbstractLaw HYSTERESIS_LAW    = new LinearLaw( 0f,    20.0,   "dB" );
    private static float LOG_0_01                      = ( float ) Math.log( 0.01 );

    private int sampleRate = 44100;
    private double threshold, inverseThreshold, thresholddB, inverseRatio, kneedB = 10.0;
    private double attack, release, gain = 1.0, dryGain = 0.0, depth = 40.0, hysteresis = 0.0;
    private boolean rms = false;

    public int hold      = 0;

    public DynamicsControls( int id, String name )
    {
        // we can use multiple of these classes
    }

    /* public methods */

    public void update( int sampleRate )
    {
        this.sampleRate = sampleRate;

        // derive sample rate dependent variables
        setAttack ( getAttack());
        setHold   ( getHold());
        setRelease( getRelease());
    }

    public boolean isRMS() { return rms; } // !!!

    public void setDynamicGain( double aValue )
    {
        // ideally we'd offload the log to another thread !!!
        // and annoyingly sometimes we already know the reduction in dBs
        // this can be used to update indicators
        aValue = 20 * Math.log( aValue );
    }

    /* getters / setters */

//	implement DynamicsProcess.Variables

    public double getThreshold()
    {
        return threshold;
    }

    public void setThreshold( double aValue )
    {
        thresholddB      = aValue;
        threshold        = VolumeUtil.log2lin( thresholddB );
        inverseThreshold = 1.0 / threshold;
    }

    public double getInverseThreshold()
    {
        return inverseThreshold;
    }

    public double getThresholddB()
    {
        return thresholddB;
    }

    public void setThresholddB( double aValue )
    {
        thresholddB = aValue;
    }

    public double getKneedB()
    {
        return kneedB;
    }

    public void setKneedB( double aValue )
    {
        kneedB = aValue;
    }

    public double getInverseRatio()
    {
        return inverseRatio;
    }

    public void setInverseRatio( double aValue )
    {
        // ratio control 1.5 .. 10, inverse ratio control 1 .. -1
        inverseRatio = aValue > 1.0 ? 1.0 / aValue : aValue;
    }

    public double getAttack()
    {
        return attack;
    }

    public void setAttack( double aValue )
    {
        attack = deriveTimeFactor( aValue );
    }

    public int getHold()
    {
        return hold;
    }

    public void setHold( int aValue )
    {
        hold = ( int )( aValue * sampleRate * 0.001 );
    }

    public double getRelease()
    {
        return release;
    }

    public void setRelease( double aValue )
    {
        release = deriveTimeFactor( aValue );
    }

    public double getDryGain()
    {
        return dryGain;
    }

    public void setDryGain( double aValue )
    {
        dryGain = VolumeUtil.log2lin( aValue );
    }

    public double getGain()
    {
        return gain;
    }

    public void setGain( double aValue )
    {
        gain = VolumeUtil.log2lin( aValue );
    }

    public double getDepth()
    {
        return depth;
    }

    public void setDepth( double aValue )
    {
        depth = VolumeUtil.log2lin( aValue );
    }

    public double getHysteresis()
    {
        return hysteresis;
    }

    public void setHysteresis( double aValue )
    {
        hysteresis = VolumeUtil.log2lin( -aValue );
    }

    /* protected */

    // http://www.physics.uoguelph.ca/tutorials/exp/Q.exp.html
    // http://www.musicdsp.org/showArchiveComment.php?ArchiveID=136
    // return per sample factor for 99% in specified milliseconds
    protected double deriveTimeFactor( double milliseconds )
    {
        final double ns = milliseconds * sampleRate * 0.001;
        final double k = LOG_0_01 / ns ; // k, per sample

        return Math.exp( k );
    }
}
