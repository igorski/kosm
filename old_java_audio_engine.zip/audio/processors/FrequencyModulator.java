package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.LFO;
import nl.igorski.lib.audio.interfaces.IProcessor;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 30-04-12
 * Time: 21:31
 * To change this template use File | Settings | File Templates.
 */
public class FrequencyModulator extends LFO implements IProcessor
{
    private double modulator;
    private double fmamp = 10;
    private double AMP_MULTIPLIER = 0.15;

    public FrequencyModulator( int aWaveForm, double aRate, int aLength )
    {
        super( aWaveForm, aRate, aLength );
    }

    /* public */

    public void process( double[] sampleBuffer )
    {
        for ( int i = 0, l = sampleBuffer.length; i < l; ++i )
        {
            modulator = modulator + ( TWO_PI_OVER_SR * _rate );
            modulator = modulator < TWO_PI ? modulator : modulator - TWO_PI;

            final double carrier = sampleBuffer[ i ];
            sampleBuffer[ i ] = ( carrier * Math.cos( carrier + fmamp * Math.cos( modulator )))/* * AMP_MULTIPLIER*/;
        }
    }
}
