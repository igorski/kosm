package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.utils.math.MathTool;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 19-04-12
 * Time: 21:55
 * To change this template use File | Settings | File Templates.
 */
public final class BitCrusher implements IProcessor
{
    private int _bits; // we scale the amount to integers in the 1-16 range

    private double _amount;

    private double _level;

    private double _levelCorrection = 1;

    public BitCrusher( double amount, double level )
    {
        setAmount( amount );
        setLevel( level );
    }

    /* public */

    public void process( double[] sampleBuffer )
    {
        for ( int i = 0, l = sampleBuffer.length; i < l; ++i )
        {
            short input = ( short ) ( sampleBuffer[ i ] * 32767 );
            short prevent_offset = ( short )( -1 >> _bits + 1 );
            input &= ( -1 << ( 16 - _bits ));
            sampleBuffer[ i ] = ((( input + prevent_offset ) * _levelCorrection ) / 32767 );
        }
    }

    /* getters / setters */

    public double getAmount()
    {
        return _amount;
    }

    public void setAmount( double value )
    {
        _amount = value;

        // scale double to 1 - 16 bit range
        _bits = ( int ) Math.floor( MathTool.scale(value, 1, 15)) + 1;

        setLevel( _level );
    }

    public double getLevel()
    {
        return _level;
    }

    public void setLevel( double value )
    {
        _level = value;

        // at lower bit resolutions the sound goes through the ceiling, auto-correct the volume
        _levelCorrection = ( _bits < 4 ) ? _level * .35 : _level;
    }
}
