package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.definitions.Pitch;
import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.renderer.AudioRenderer;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 5/25/12
 * Time: 2:02 PM
 * To change this template use File | Settings | File Templates.
 */
public final class DCOffsetFilter implements IProcessor
{
    private double lastSample;

    private double R;

    /**
     * The DCOffsetFilter monitors an audio buffer for large
     * leaps at the sample level indicating a nasty "pop" or
     * "click" which is caused by a DC offset
     */
    public DCOffsetFilter()
    {
        lastSample = 0.0;
        R          = 1.0 - ( Math.PI * 2 * Pitch.note( "C", 2 ) / AudioRenderer.SAMPLE_RATE );
    }

    /* public methods */

    public void process( double[] sampleBuffer )
    {
        /**
         * This is based on code found in the document:
         * "Introduction to Digital Filters (DRAFT)"
         * Julius O. Smith III (jos@ccrma.stanford.edu)
         * (http://www-ccrma.stanford.edu/~jos/filters/)
         * ---
         *
         * Some audio algorithms (asymmetric waveshaping, cascaded filters, ...) can produce DC offset.
         * This offset can accumulate and reduce the signal/noise ratio.
         *
         * So, how to fix it? The example code from Julius O. Smith's document is:
         * ...
         * y(n) = x(n) - x(n-1) + R * y(n-1)
         * // "R" between 0.9 .. 1
         * // n=current (n-1)=previous in/out value
         * ...
         * "R" depends on sampling rate and the low frequency point. Do not set "R" to a fixed value (e.g. 0.99)
         * if you don't know the sample rate. Instead set R to:
         *
         * (-3dB @ 40Hz): R = 1-(250/samplerate)
         *
         * How to calculate "R" for a given (-3dB) low frequency point?
         * R = 1 - (pi*2 * frequency /samplerate)
         */
        for ( int i = 0, l = sampleBuffer.length; i < l; ++i )
        {
            final double theSample = R * ( lastSample + sampleBuffer[ i ] - lastSample );
            lastSample = theSample;

            sampleBuffer[ i ] = theSample;
        }
    }
}
