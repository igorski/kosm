package nl.igorski.lib.audio.processors;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 5/25/12
 * Time: 2:02 PM
 * To change this template use File | Settings | File Templates.
 */
public final class Finalizer extends Limiter
{
    private short lastSample = 0;

    private double lastDSample = 0.0;

    /**
     * Finalizer should be seen as the "final" processor in a typical setting, it is essentially
     * a limiter making sure no clipping occurs, as well as a preventive measure to omit
     * nasty pops and clicks caused by DC offsets
     *
     * @param attackMs   {double} attack time in milliseconds
     * @param releaseMs  {double} attack decay time in milliseconds
     * @param sampleRate {int} the current samplerate
     */
    public Finalizer( double attackMs, double releaseMs, int sampleRate )
    {
        super( attackMs, releaseMs, sampleRate );
    }

    /* public methods */

    @Override
    public short[] process( double[] sampleBuffer )
    {
        final short[] output = super.process( sampleBuffer );

        for ( int i = 0, l = output.length; i < l; ++i )
        {
            final short theSample = ( short ) ( 0.996 * ( lastSample + output[ i ] - lastSample ));
            lastSample = theSample;

            output[ i ] = theSample;
        }
        return output;
    }

    /**
     * used by the AudioBouncer, which doesn't need shorts!
     * @param sampleBuffer {double[]} buffer containing samples to limit
     * @return {double[]} limited buffer
     */
    public double[] limitDoubles( double[] sampleBuffer )
    {
        final double[] output = super.limitDoubles( sampleBuffer );

        for ( int i = 0, l = output.length; i < l; ++i )
        {
            final double theSample = 0.996 * ( lastDSample + output[ i ] - lastDSample );
            lastDSample = theSample;

            output[ i ] = theSample;
        }
        return output;
    }
}
