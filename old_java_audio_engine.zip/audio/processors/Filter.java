package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.LFO;
import nl.igorski.lib.audio.renderer.AudioRenderer;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 19-04-12
 * Time: 21:55
 * To change this template use File | Settings | File Templates.
 */
public final class Filter implements IProcessor
{
    protected double _cutoff       = 0;
    protected double _resonance    = Math.sqrt( 2 );
    protected double _tempCutoff   = 0;    // used for reading when automating via LFO

    // LFO related

    protected LFO _lfo;
    protected double minFreq;
    protected double maxFreq;
    protected double lfoRange;

    protected double fs         = AudioRenderer.SAMPLE_RATE;

    // filter specific, used internally

    protected double a1;
    protected double a2;
    protected double a3;
    protected double b1;
    protected double b2;
    protected double c;

    protected double in1;
    protected double in2;
    protected double out1;
    protected double out2;
    protected double output;

    protected int lfoOffset;

    /**
     * @param aCutoffFrequency {double} desired cutoff frequency in Hz
     * @param aResonance {double} resonance
     * @param aMinFreq {double} minimum cutoff frequency in Hz, required for LFO automation
     * @param aMaxFreq {double} maximum cutoff frequency in Hz, required for LFO automation
     * @param aLfoRate {double} LFO speed in Hz, 0 for OFF
     */
    public Filter( double aCutoffFrequency, double aResonance, double aMinFreq, double aMaxFreq, double aLfoRate )
    {
        _resonance = aResonance;
        setCutoff ( aCutoffFrequency );
        setLFORate( aLfoRate );

        minFreq    = aMinFreq;
        maxFreq    = aMaxFreq;
        lfoRange   = ( maxFreq * .5 ) - minFreq;

        in1 = in2 = out1 = out2 = 0;

        calculateParameters();
    }

    /* public */

    public void process( double[] sampleBuffer )
    {
        final boolean doLFO = _lfo != null;

        for ( int i = 0, j = sampleBuffer.length; i < j; ++i )
        {
            final double input = sampleBuffer[ i ];

            output = a1 * input + a2 * in1 + a3 * in2 - b1 * out1 - b2 * out2;

            in2  = in1;
            in1  = input;
            out2 = out1;
            out1 = output;

            // oscillator attached to Filter ? travel the cutoff values
            // between the minimum and half way the maximum frequencies, as
            // defined by lfoRange in the class constructor

            if ( doLFO )
            {
                _tempCutoff = _cutoff + ( lfoRange * _lfo.buffer[ lfoOffset ]);

                if ( _tempCutoff > maxFreq )
                    _tempCutoff = maxFreq;

                else if ( _tempCutoff < minFreq )
                    _tempCutoff = minFreq;

                if ( ++lfoOffset >= _lfo.length )
                    lfoOffset = 0;

                calculateParameters();
            }
            // commit the effect
            sampleBuffer[ i ] = output;
        }
    }

    public void setCutoff( double frequency )
    {
        _cutoff = frequency;

        if ( _cutoff >= AudioRenderer.SAMPLE_RATE * .5 )
            _cutoff = AudioRenderer.SAMPLE_RATE * .5 - 1;

        if ( _cutoff < minFreq )
            _cutoff = minFreq;

        _tempCutoff = _cutoff;

        calculateParameters();
    }

    public double getCutoff()
    {
        return _cutoff;
    }

    public void setResonance( double resonance )
    {
        _resonance = resonance;

        calculateParameters();
    }

    public double getResonance()
    {
        return _resonance;
    }

    public double getLFO()
    {
        if ( _lfo != null )
            return _lfo.getRate();

        return 0;
    }

    public void setLFO( LFO lfo )
    {
        _lfo      = lfo;
        lfoOffset = 0;
    }

    public void setLFORate( double rate )
    {
        if ( rate == 0 )
        {
            _lfo        = null;
            _tempCutoff = _cutoff;
            return;
        }
        _lfo.setRate( rate );

        lfoOffset = 0;
    }

    /* private */

    private void calculateParameters()
    {
        c = 1 / Math.tan( Math.PI * _tempCutoff / fs );
        a1 = 1.0 / ( 1.0 + _resonance * c + c * c);
        a2 = 2 * a1;
        a3 = a1;
        b1 = 2.0 * ( 1.0 - c * c ) * a1;
        b2 = ( 1.0 - _resonance * c + c * c) * a1;
    }
}
