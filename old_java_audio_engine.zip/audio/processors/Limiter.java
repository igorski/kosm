package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.utils.EnvelopeFollower;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 5/25/12
 * Time: 2:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class Limiter
{
    private EnvelopeFollower _follower;

    private int skip;

    private double maxGain = .85f;

    /**
     * creates a limiter, attack 10 ms works well with decay 500 ms for average use
     *
     * @param attackMs   {double} attack time in milliseconds
     * @param releaseMs  {double} attack decay time in milliseconds
     * @param sampleRate {int} the current samplerate
     */
    public Limiter( double attackMs, double releaseMs, int sampleRate )
    {
        _follower = new EnvelopeFollower( maxGain, attackMs, releaseMs, sampleRate );
        skip      = 0; // channel amount minus 1 apparently
    }

    /* public */

    public double getLinearGR()
    {
        return _follower.envelope > 1. ? 1 / _follower.envelope : 1.;
    }

    public short[] process( double[] sampleBuffer )
    {
        // I don't want the left and right sides to get scaled differently, that would be silly.
        // So I call Process() once on my interleaved stereo data with twice the number of
        // frames, and skip = 1.

        final short[] output = new short[ sampleBuffer.length ];

        // 32767 being the max value for a short
        int i = sampleBuffer.length;

        while ( i-- > 0 )
        {
            double dest = sampleBuffer[ i ];

            _follower.process( dest, skip );

            if ( _follower.envelope > maxGain )
                dest = dest / _follower.envelope;

            // extreme limiting (still above the thresholds?)
            if ( dest < -1.0 )
                dest = -1.0;

            else if ( dest  > +1.0 )
                dest = +1.0;

            output[ i ] = ( short ) (( dest + skip ) * 32767 );
        }
        return output;
    }

    /**
     * used by the AudioBouncer, which doesn't need shorts!
     * @param sampleBuffer {double[]} buffer containing samples to limit
     * @return {double[]} limited buffer
     */
    public double[] limitDoubles( double[] sampleBuffer )
    {
        int i = sampleBuffer.length;

        while ( i-- > 0 )
        {
            double dest = sampleBuffer[ i ];

            _follower.process( dest, skip );

            if ( _follower.envelope > maxGain )
                dest = dest / _follower.envelope;

            // extreme limiting (still above the thresholds?)
            if ( dest < -1.0 )
                dest = -1.0;

            else if ( dest  > +1.0 )
                dest = +1.0;

            sampleBuffer[ i ] = ( dest + skip );
        }
        return sampleBuffer;
    }
}
