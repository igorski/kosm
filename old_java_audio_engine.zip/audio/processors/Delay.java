package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.interfaces.IBusProcessor;
import nl.igorski.lib.audio.renderer.AudioRenderer;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 19-04-12
 * Time: 21:53
 * To change this template use File | Settings | File Templates.
 */
public final class Delay implements IBusProcessor
{
    private double[] _delayBuffer;

    private int _delayIndex;

    private int _time;

    private double _mix;

    private double _feedback;

    //_________________________________________________________________________________________________________
    //                                                                                    C O N S T R U C T O R

    /**
     * @param aDelayTime {double} in milliseconds, time between consecutive repeats
     * @param aMix       {double} 0-1, percentage of dry/wet mix
     * @param aFeedback  {double} 0-1, amount of repeats
     */
    public Delay( double aDelayTime, double aMix, double aFeedback )
    {
        _time        = ( int ) Math.round(( AudioRenderer.SAMPLE_RATE * .001 ) * aDelayTime );
        _delayBuffer = new double[ _time ];
        _mix         = aMix;
        _feedback    = aFeedback;

         // TODO: make stereo ? ( twin buffers )

        _delayIndex = 0;
    }

    /* public */

    /**
     * run an audio signal through the delay line
     * and add the delay effect
     * @param sampleBuffer {double[]}
     */
    public void apply( double[] sampleBuffer )
    {
        double delay;

        int readIndex;

        for ( int i = 0, j = sampleBuffer.length; i < j; ++i )
        {
            readIndex = _delayIndex - _time + 1;

            if( readIndex < 0 )
                readIndex += _time;

            // read the previously delayed samples from the buffer
            // ( for feedback purposes ) and append the current sample to it

            delay = _delayBuffer[ readIndex ];

            _delayBuffer[ _delayIndex ] = sampleBuffer[ i ] + delay * _feedback;

            if( ++_delayIndex == _time )
                _delayIndex = 0;

            // higher feedback levels cause a massive noisefest, "limit" them!
            if ( _feedback > .5 )
                sampleBuffer[ i ] += ( delay * _mix * ( 1.5 - _feedback ));
            else
                sampleBuffer[ i ] += ( delay * _mix );
        }
    }

    //_________________________________________________________________________________________________________
    //                                                                        G E T T E R S   /   S E T T E R S

    public double getDelayTime()
    {
        return _time / ( AudioRenderer.SAMPLE_RATE * .001 );
    }

    public void setDelayTime( double aValue )
    {
        _time        = ( int ) Math.round(( AudioRenderer.SAMPLE_RATE * .001 ) * aValue );
        _delayBuffer = new double[ _time ];

        if ( _delayIndex > _time )
            _delayIndex = 0;
    }

    public double getMix()
    {
        return _mix;
    }

    public void setMix( double aValue )
    {
        _mix = aValue;
    }

    public double getFeedback()
    {
        return _feedback;
    }

    public void setFeedback( double aValue )
    {
        _feedback = aValue;
    }
}
