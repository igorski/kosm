package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.interfaces.IProcessor;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 19-04-12
 * Time: 21:55
 * To change this template use File | Settings | File Templates.
 */
public final class WaveShaper implements IProcessor
{
    private double _amount;
    private double _level;

    public WaveShaper( double amount, double level )
    {
        _amount = amount;
        _level  = level;
    }

    /* public */

    public void process( double[] sampleBuffer )
    {
        for ( int i = 0, l = sampleBuffer.length; i < l; ++i )
        {
            double input = sampleBuffer[ i ];
            input = ( input * ( Math.abs( input ) + _amount ) / (( int )input ^ 2 ) + ( _amount - 1 ) * Math.abs( input ) + 1 );
            sampleBuffer[ i ] = input * _level;
        }
    }

    public double getAmount()
    {
        return _amount;
    }

    public void setAmount( double value )
    {
        _amount = value;
    }

    public double getLevel()
    {
        return _level;
    }

    public void setLevel( double value )
    {
        _level = value;
    }
}
