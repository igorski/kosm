package nl.igorski.lib.audio.processors;

import nl.igorski.lib.audio.interfaces.IProcessor;
import nl.igorski.lib.audio.renderer.AudioRenderer;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 26-01-13
 * Time: 13:46
 * To change this template use File | Settings | File Templates.
 */
public final class LPFHPFilter implements IProcessor
{
    private double a0;
    private double a1;
    private double b0;
    private double b1;

    private double _prevSample            = 0.0;
    private double _prevUnprocessedSample = _prevSample;

    public LPFHPFilter( double aLPCutoff, double aHPCutoff )
    {
        setLPF( aLPCutoff, AudioRenderer.SAMPLE_RATE );
        setHPF( aHPCutoff, AudioRenderer.SAMPLE_RATE );
    }

    /* public methods */

    public void setLPF( double aCutOffFrequency, double aSampleRate )
    {
        final double w = 2.0 * aSampleRate;
        double Norm;

        aCutOffFrequency *= 2.0 * Math.PI;
        Norm              = 1.0 / ( aCutOffFrequency + w );
        b1                = ( w - aCutOffFrequency ) * Norm;
        a0                = a1 = aCutOffFrequency * Norm;
    }

    public void setHPF( double aCutOffFrequency, double aSampleRate )
    {
        final double w = 2.0 * aSampleRate;
        double Norm;

        aCutOffFrequency *= 2.0 * Math.PI;
        Norm              = 1.0 / ( aCutOffFrequency + w );
        a0                = w * Norm;
        a1                = -a0;
        b1                = ( w - aCutOffFrequency ) * Norm;
    }

    public void process( double[] sampleBuffer )
    {
        for ( int i = 0, l = sampleBuffer.length; i < l; ++i )
        {
            final double curUnprocessedSample = sampleBuffer[ i ];

            if ( i > 0 )
                _prevSample = sampleBuffer[ i - 1 ];

            sampleBuffer[ i ]      = curUnprocessedSample * a0 + _prevUnprocessedSample * a1 + _prevSample * b1;
            _prevUnprocessedSample = curUnprocessedSample;

//            out[n] = in[n]*a0 + in[n-1]*a1 + out[n-1]*b1;
        }
    }
}
