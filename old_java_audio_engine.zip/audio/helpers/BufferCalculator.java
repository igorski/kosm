package nl.igorski.lib.audio.helpers;

import nl.igorski.lib.utils.TypeConverter;

/**
 * Created by IntelliJ IDEA.
 * User: igorzinken
 * Date: 4/12/12
 * Time: 3:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class BufferCalculator
{
    /* BufferCalculator provides several functions for basic time / BPM related calculations */
    /* NOTE: these are set for 4/4 bars ( TODO : extend for flexible time signatures )  */

    /* public */

    /**
     * get the tempo in Beats per Minute from the length
     * in milliseconds of a audio snippet
     *
     * @length       {double} length in milliseconds
     * @amountOfBars {int} the amount of bars the snippet lasts
     *
     * @return {double}
     */
    public static double getBPMbyLength( double length, int amountOfBars )
    {
        // length to seconds
        length *= .001;

        return 240 / ( length / amountOfBars );
    }

    /**
     * get the tempo in Beats per Minute by the length in
     * samples of a audio snippet
     *
     * @length       {int} length in samples
     * @amountOfBars {int} the amount of bars the snippet lasts
     * @sampleRate   {int} sampleRate in Hz
     *
     * @return {double}
     */
    public static double getBPMbySamples( int length, int amountOfBars, int sampleRate )
    {
         return 240 / (( length / amountOfBars ) / sampleRate );
    }

    /**
     * return the contents of a given buffer as its length in milliseconds
     *
     * @param {int} bufferSize
     * @param {int} sampleRate in Hz
     *
     * @return {int}
     */
    public static int bufferToMilliseconds( int bufferSize, int sampleRate )
    {
        return ( int ) ( bufferSize / ( sampleRate * .001 ));
    }

    /**
     * return the required buffer size for a value in milliseconds
     *
     * @param {int} milliSeconds
     * @param {int} sampleRate in Hz
     *
     * @return {int}
     */
    public static int millisecondsToBuffer( int milliSeconds, int sampleRate )
    {
        return ( int ) ( milliSeconds * ( sampleRate * .001 ));
    }

    /**
     * calculate the bitRate of a given audiostream
     *
     * @sampleRate  {int} sampleRate in Hz
     * @bitDepth    {int} bit depth
     * @channels    {int} the amount of audio channels
     *
     * @return {double}
     */
    public static double getBitRate( int sampleRate, int bitDepth, int channels )
    {
        return sampleRate * bitDepth * channels;
    }

    /**
     * calculations within a musical context:
     * calculate the sample length required for each
     * beat at a given tempo
     *
     * @tempo          {double} tempo in BPM
     * @sampleRate     {int} the sample rate in Hz
     *
     * @return {int}
     */

    public static int calculateSamplesBerBeat( double tempo, int sampleRate )
    {
        return TypeConverter.longToInt( Math.round(( sampleRate * 60 ) / tempo ));
    }

    public static int calculateSixteenthNoteSamples( double tempo, int sampleRate )
    {
        return ( int )( Math.round(( sampleRate * 60 ) / tempo ) * .25 );
    }
}
